/*
 * Copyright 2016 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.drools.workbench.screens.guided.dtable.client.editor.menu;

import java.util.Optional;

import org.drools.workbench.screens.guided.dtable.client.widget.table.GuidedDecisionTableView;
import org.drools.workbench.screens.guided.dtable.client.widget.table.events.cdi.DecisionTableSelectedEvent;
import org.drools.workbench.screens.guided.dtable.client.widget.table.events.cdi.DecisionTableSelectionsChangedEvent;
import org.drools.workbench.screens.guided.dtable.client.widget.table.events.cdi.RefreshMenusEvent;

/**
 * Base Menu implementation for MenuItems that need to be aware of Decision Table and Decision Table Cell selections.
 */
public abstract class BaseMenu implements BaseMenuView.BaseMenuPresenter {

    protected GuidedDecisionTableView.Presenter activeDecisionTable;

    @Override
    public void onDecisionTableSelectedEvent(final DecisionTableSelectedEvent event) {
        final Optional<GuidedDecisionTableView.Presenter> dtPresenter = event.getPresenter();
        activeDecisionTable = dtPresenter.orElse(null);
        initialise();
    }

    @Override
    public void onDecisionTableSelectionsChangedEvent(final DecisionTableSelectionsChangedEvent event) {
        final GuidedDecisionTableView.Presenter dtPresenter = event.getPresenter();
        activeDecisionTable = dtPresenter;
        initialise();
    }

    @Override
    public void onRefreshMenusEvent(final RefreshMenusEvent event) {
        initialise();
    }
}
