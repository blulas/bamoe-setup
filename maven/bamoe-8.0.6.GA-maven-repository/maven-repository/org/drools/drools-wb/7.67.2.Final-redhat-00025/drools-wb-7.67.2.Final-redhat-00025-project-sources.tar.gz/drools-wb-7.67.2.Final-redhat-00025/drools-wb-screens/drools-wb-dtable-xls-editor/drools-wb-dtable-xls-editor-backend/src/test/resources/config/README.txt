This file is needed to preserve this directory (config/).
The config directory must exist in order for the simple-jndi:simple-jndi to do it's 
JNDI tricks.