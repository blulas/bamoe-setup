package org.jbpm.simple;

public class Simple {

    public static void main(String[] args) {
        System.out.println("Hello, I'm a simple class...");
    }
}