# Pastebin Workitems - prerequisite

* To use these workitems first create an account on https://pastebin.com/.
Once you create an account go to
https://pastebin.com/api to get your developer API key. This key 
needs to be passed to the handlers in your deployment descriptor configuration.

* To use the GetExistingPastebin workitem handler it's necessary to have 
your IP authorized. See more info on this on https://pastebin.com/api_scraping_faq.
