Docker Workitems
========================================

jBPM Docker workitems assume that you configure Docker settings using System environment 
variables. For more information on how to configure this please look at :

https://github.com/docker-java/docker-java

and 

https://www.baeldung.com/docker-java-api    