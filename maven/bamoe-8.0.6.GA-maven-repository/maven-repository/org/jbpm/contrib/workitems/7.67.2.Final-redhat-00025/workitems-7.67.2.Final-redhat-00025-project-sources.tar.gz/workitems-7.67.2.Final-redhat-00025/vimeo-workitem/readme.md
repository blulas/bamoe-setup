# Vimeo Workitems - prerequisite

To use these workitems create account / log in to https://developer.vimeo.com/apps.
Then you need to generate an app. Once generated you need to request upload access for your
app. When request is granted you will be able to use the access token in your workitem handlers
to upload videos to your app.