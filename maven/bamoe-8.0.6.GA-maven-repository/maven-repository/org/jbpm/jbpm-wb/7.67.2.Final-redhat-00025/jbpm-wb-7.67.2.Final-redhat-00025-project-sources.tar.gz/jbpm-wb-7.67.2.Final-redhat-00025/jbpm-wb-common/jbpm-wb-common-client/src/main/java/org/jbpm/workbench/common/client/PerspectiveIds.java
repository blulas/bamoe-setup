/*
 * Copyright 2018 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jbpm.workbench.common.client;

public interface PerspectiveIds extends org.kie.workbench.common.services.shared.resources.PerspectiveIds {

    String SEARCH_PARAMETER_PROCESS_INSTANCE_ID = "processInstanceId";
    String SEARCH_PARAMETER_PROCESS_DEFINITION_ID = "processDefinitionId";
    String SEARCH_PARAMETER_TASK_ID = "taskId";
    String SEARCH_PARAMETER_JOB_ID = "jobId";
    String SEARCH_PARAMETER_ERROR_TYPE = "errorType";
    String SEARCH_PARAMETER_IS_ERROR_ACK = "isErrorAck";

    String PROCESS_INSTANCE_DETAILS_SCREEN = "ProcessInstanceDetailsScreen";
    String PROCESS_INSTANCE_LIST_SCREEN = "ProcessInstanceListScreen";
    String PROCESS_DEFINITION_DETAILS_SCREEN = "ProcessDefinitionDetailsScreen";
    String PROCESS_DEFINITION_LIST_SCREEN = "ProcessDefinitionListScreen";
    String PROCESS_DASHBOARD_SCREEN = "ProcessDashboardScreen";
    String TASK_DASHBOARD_SCREEN = "TaskDashboardScreen";
    String EXECUTION_ERROR_DETAILS_SCREEN = "ExecutionErrorDetailsScreen";
    String EXECUTION_ERROR_LIST_SCREEN = "ExecutionErrorListScreen";
    String JOB_LIST_SCREEN = "JobListScreen";
    String JOB_DETAILS_SCREEN = "JobDetailsScreen";
    String TASK_ADMIN_LIST_SCREEN = "TaskAdminListScreen";
    String TASK_LIST_SCREEN = "TaskListScreen";
    String TASK_DETAILS_SCREEN = "TaskDetailsScreen";

    String JOB_LIST_BASIC_FILTERS_SCREEN = "JobListBasicFiltersScreen";
    String EXECUTION_ERROR_LIST_BASIC_FILTERS_SCREEN = "ErrorListBasicFiltersScreen";
    String PROCESS_INSTANCE_LIST_BASIC_FILTERS_SCREEN = "ProcessInstanceListBasicFiltersScreen";
    String TASK_ADMIN_LIST_BASIC_FILTERS_SCREEN = "TaskAdminListBasicFiltersScreen";
    String TASK_LIST_BASIC_FILTERS_SCREEN = "TaskListBasicFiltersScreen";

    String JOB_LIST_ADVANCED_FILTERS_SCREEN = "JobListAdvancedFiltersScreen";
    String EXECUTION_ERROR_LIST_ADVANCED_FILTERS_SCREEN = "ErrorListAdvancedFiltersScreen";
    String PROCESS_INSTANCE_LIST_ADVANCED_FILTERS_SCREEN = "ProcessInstanceListAdvancedFiltersScreen";
    String TASK_ADMIN_LIST_ADVANCED_FILTERS_SCREEN = "TaskAdminListAdvancedFiltersScreen";
    String TASK_LIST_ADVANCED_FILTERS_SCREEN = "TaskListAdvancedFiltersScreen";

    String JOB_LIST_SAVED_FILTERS_SCREEN = "JobListSavedFiltersScreen";
    String EXECUTION_ERROR_LIST_SAVED_FILTERS_SCREEN = "ExecutionErrorListSavedFiltersScreen";
    String PROCESS_INSTANCE_LIST_SAVED_FILTERS_SCREEN = "ProcessInstanceListSavedFiltersScreen";
    String TASK_ADMIN_LIST_SAVED_FILTERS_SCREEN = "TaskAdminListSavedFiltersScreen";
    String TASK_LIST_SAVED_FILTERS_SCREEN = "TaskListSavedFiltersScreen";
}