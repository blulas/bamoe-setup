package ${package};


public class Model {


}