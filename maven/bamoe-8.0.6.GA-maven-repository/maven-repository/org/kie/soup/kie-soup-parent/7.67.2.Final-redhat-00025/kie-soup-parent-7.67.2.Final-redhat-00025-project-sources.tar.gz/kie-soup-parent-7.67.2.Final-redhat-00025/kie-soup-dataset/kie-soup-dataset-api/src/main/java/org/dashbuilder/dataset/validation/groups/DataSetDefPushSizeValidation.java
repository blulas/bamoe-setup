package org.dashbuilder.dataset.validation.groups;

/**
 * <p>Validation group for the attribute <code>pushMaxSize</code> of the data set definition class.</p>
 */
public interface DataSetDefPushSizeValidation {
}
