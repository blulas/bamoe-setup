package org.dashbuilder.dataset.validation.groups;

/**
 * <p>Validation group for the attribute <code>cacheMaxRows</code> of the data set definition class.</p>
 */
public interface DataSetDefCacheRowsValidation {

}