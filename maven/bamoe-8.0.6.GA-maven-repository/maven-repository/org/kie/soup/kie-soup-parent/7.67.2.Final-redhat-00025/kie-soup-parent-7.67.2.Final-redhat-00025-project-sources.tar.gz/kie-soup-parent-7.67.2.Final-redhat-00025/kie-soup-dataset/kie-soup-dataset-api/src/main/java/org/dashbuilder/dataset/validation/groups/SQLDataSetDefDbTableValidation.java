package org.dashbuilder.dataset.validation.groups;

/**
 * <p>Validation group for the attribute <code>dbTable</code> of the SQL data set definition class.</p>
 */
public interface SQLDataSetDefDbTableValidation {
}
