package org.dashbuilder.dataset.validation.groups;

/**
 * <p>Validation group for the attribute <code>filePath</code> of the CSV data set definition class.</p>
 */
public interface CSVDataSetDefFilePathValidation {
}
