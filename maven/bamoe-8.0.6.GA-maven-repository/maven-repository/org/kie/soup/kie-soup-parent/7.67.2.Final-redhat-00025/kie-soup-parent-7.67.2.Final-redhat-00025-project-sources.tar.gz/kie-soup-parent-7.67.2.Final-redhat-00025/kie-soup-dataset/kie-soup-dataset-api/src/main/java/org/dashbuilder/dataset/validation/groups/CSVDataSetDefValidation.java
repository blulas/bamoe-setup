package org.dashbuilder.dataset.validation.groups;

/**
 * <p>Validation group for initial mandatory attributes of the CSV data set definition.</p>
 */
public interface CSVDataSetDefValidation {
}
