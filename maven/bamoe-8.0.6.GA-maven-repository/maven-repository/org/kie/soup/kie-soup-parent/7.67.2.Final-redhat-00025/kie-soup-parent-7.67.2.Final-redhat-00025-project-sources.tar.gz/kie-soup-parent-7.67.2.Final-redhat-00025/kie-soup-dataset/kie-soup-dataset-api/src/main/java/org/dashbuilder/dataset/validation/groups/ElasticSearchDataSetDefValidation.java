package org.dashbuilder.dataset.validation.groups;

/**
 * <p>Validation group for initial mandatory attributes of the ElasticSearch data set definition.</p>
 */
public interface ElasticSearchDataSetDefValidation {
}
