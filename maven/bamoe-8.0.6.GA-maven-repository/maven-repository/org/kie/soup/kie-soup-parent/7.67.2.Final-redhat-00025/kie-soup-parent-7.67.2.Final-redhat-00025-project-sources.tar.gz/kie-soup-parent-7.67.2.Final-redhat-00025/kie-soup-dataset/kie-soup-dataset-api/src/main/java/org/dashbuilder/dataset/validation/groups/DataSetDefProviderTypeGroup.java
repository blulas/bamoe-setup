package org.dashbuilder.dataset.validation.groups;

/**
 * @since 0.4.0
 */
public interface DataSetDefProviderTypeGroup {
}
