package testscenario;
/**
* Do not remove this file
*/
@org.junit.runner.RunWith(org.drools.scenariosimulation.backend.runner.ScenarioJunitActivator.class)
public class ScenarioJunitActivatorTest {
}