drop table migration_report_logs cascade constraints;
drop table migration_reports cascade constraints;
drop table migrations cascade constraints;
drop table plan_mappings cascade constraints;
drop table plans cascade constraints;
drop table process_instance_ids cascade constraints;
drop sequence MIG_REP_ID_SEQ;
drop sequence MIGRATION_ID_SEQ;
drop sequence PLAN_ID_SEQ;
