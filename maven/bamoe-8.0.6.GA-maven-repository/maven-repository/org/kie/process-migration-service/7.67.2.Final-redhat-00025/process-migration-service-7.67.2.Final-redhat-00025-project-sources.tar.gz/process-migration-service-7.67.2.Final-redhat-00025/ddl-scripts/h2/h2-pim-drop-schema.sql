drop table if exists migration_report_logs CASCADE ;
drop table if exists migration_reports CASCADE ;
drop table if exists migrations CASCADE ;
drop table if exists plan_mappings CASCADE ;
drop table if exists plans CASCADE ;
drop table if exists process_instance_ids CASCADE ;
drop sequence if exists MIG_REP_ID_SEQ;
drop sequence if exists MIGRATION_ID_SEQ;
drop sequence if exists PLAN_ID_SEQ;
