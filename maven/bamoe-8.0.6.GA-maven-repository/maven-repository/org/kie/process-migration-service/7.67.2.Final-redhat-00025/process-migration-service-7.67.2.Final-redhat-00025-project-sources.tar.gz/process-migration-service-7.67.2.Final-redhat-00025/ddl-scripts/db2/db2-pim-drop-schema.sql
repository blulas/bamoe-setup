drop table migration_report_logs;
drop table migration_reports;
drop table migrations;
drop table plan_mappings;
drop table plans;
drop table process_instance_ids;
drop sequence MIG_REP_ID_SEQ restrict;
drop sequence MIGRATION_ID_SEQ restrict;
drop sequence PLAN_ID_SEQ restrict;
