alter table migration_reports
  drop foreign key FK98ckwvu4fyt55u6sq680xwkmx;