alter table migration_report_logs alter column log type oid;
alter table migrations alter column error_message type oid;