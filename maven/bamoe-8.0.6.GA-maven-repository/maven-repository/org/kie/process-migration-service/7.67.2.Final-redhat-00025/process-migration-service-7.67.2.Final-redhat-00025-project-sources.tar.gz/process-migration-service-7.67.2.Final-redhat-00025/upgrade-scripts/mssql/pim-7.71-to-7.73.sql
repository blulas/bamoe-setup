alter table migration_reports
  drop constraint FK98ckwvu4fyt55u6sq680xwkmx;