//setupJest.js or similar file
// eslint-disable-next-line no-undef
global.fetch = require("jest-fetch-mock");
