alter table if exists migration_reports
  drop constraint if exists FK98ckwvu4fyt55u6sq680xwkmx;